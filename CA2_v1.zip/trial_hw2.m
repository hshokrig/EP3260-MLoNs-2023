clc; clear; close all;

% %% Data Import
% 
% list = dir('ghg_data/*.dat');
% 
% for k=1:length(list)
%    FileNames=list(k).name;
%    A=readtable(['ghg_data/',FileNames]);
%    Z = table2array(A(1:15,:));
%    X(:,k) = Z(:);
%    Y(k,:)=table2array(A(16,:));   
% end

load('dataset.mat');

%% Preprocess
A = [X; Y'];

A = (A ./ (max(max(A)))).*1000;

X_data = A(1:4905,:);
Y_data = A(4906:end,:);


X_train = X_data(:,1:2500);
Y_train = Y_data(:,1:2500).';

X_test = X_data(:,2501:end);
Y_test = Y_data(:,1:2501:end).';

lambda = 0.01;
alpha = 1;
epsilon = 1e-5;
number_of_iterations = 60;
[weights,cost] = solve_gradient_descent(X_train,Y_train,lambda,alpha,epsilon, number_of_iterations);




