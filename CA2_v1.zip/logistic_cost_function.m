function [cost_value] = logistic_cost_function(X_data, Y_data, weights, lambda)

D = size(X_data,1);
N = size(X_data,2);
logistic_cost=0;
for sample_count=1:N
     x_sample = X_data(:,sample_count);
     y_sample = Y_data(sample_count,:);
    LG_update= log(1+exp(-y_sample*(weights'*x_sample)));
    logistic_cost= logistic_cost+LG_update;
end
cost_value = logistic_cost/N + lambda*(norm(weights)^2);


end