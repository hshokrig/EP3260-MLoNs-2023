clc
clear 
close all



%% Data Import

% list = dir('ghg_data/*.dat');
% X=[];
% 
% Y=[];
% for k=1:length(list)
%    dat_file=list(k).name;
%    A=importdata(['ghg_data/',dat_file]);
%    X_temp=[reshape(A(1:16,:),1,[])];
%    X_temp(end)=[];
%    X=[X;X_temp];
%    Y=[Y; A(16,327)];
% end
% 
% X=X';   %5231x2921
% Y=Y';   %1x2921
% save('X.mat','X')
% save('Y.mat','Y')
load('X.mat','X');
load('Y.mat','Y');

%% Define solvers: GD, SGD, SVRG and SAG. l
alpha = .1; % change the value
num_iters = 1:10:100; % change the value
lambda_ = .1; % change the value
epsilon = 10^-6; % change the value
mem=false;
cost_plot=[];
for opt_cnt=1:4
    if opt_cnt==1
        opt='GD';
    elseif opt_cnt==2
        opt='SGD';
    elseif opt_cnt==3
        opt='SVRG';
    elseif opt_cnt==4
        opt='SAG';
    end


    indx_cnt=1;
    for i=num_iters
        W=rand(size(X,1),size(Y,1));

        start_time=tic;
        W_gd=solver(X,Y,W,alpha,i,lambda_,epsilon,opt,mem);
        end_time=toc(start_time);
        cost_plot(indx_cnt,opt_cnt)=cost(X,Y,W_gd,lambda_)
        time_plot(indx_cnt,opt_cnt)=end_time;
        indx_cnt=indx_cnt+1;
    end
end
figure(1)
plot(num_iters, cost_plot(:,1),num_iters, cost_plot(:,2),num_iters,cost_plot(:,3),num_iters,cost_plot(:,4),LineWidth=1.3)
xlabel('No. of iterations')
ylabel('Cost function value')
title('Cost function with parameters \alpha=0.1, \lambda=0.1,\epsilon=10^{-6}')
legend('GD','SGD','SVRG','SAG')
figure(2)
plot(num_iters, time_plot(:,1),num_iters, time_plot(:,2),num_iters,time_plot(:,3),num_iters,time_plot(:,4),LineWidth=1.3)
xlabel('No. of iterations')
ylabel('Computation time in seconds')
title('Computation time with parameters \alpha=0.1, \lambda=0.1,\epsilon=10^{-6}')
legend('GD','SGD','SVRG','SAG')



%% Tunning the hyper-paramter

x=X;
y=Y;
% Initialize the hyperparameters to be tuned
alpha_values = [0.1, 0.01, 0.001, 0.0001];
lambda_values = [0.01, 0.1, 1, 10];
num_iters_values = [50, 100, 200, 300];
epsilon_values = [0.1, 0.01, 0.001, 0.0001];

% Initialize the results matrix
results = zeros(length(alpha_values)*length(lambda_values)*length(num_iters_values)*length(epsilon_values), 12);

% Counter for keeping track of the index in the results matrix
count = 0;

% Iterate over all combinations of hyperparameters
for alpha = alpha_values
    for lambda_ = lambda_values
        for num_iters = num_iters_values
            for epsilon = epsilon_values
                count
                % Print the current combination of hyperparameters
                fprintf('alpha=%f, lambda_=%f, num_iters=%d, epsilon=%f\n', ...
                    alpha, lambda_, num_iters, epsilon);
                
                % Set the seed for reproducibility
                rng(1);
                
                % Initialize the weights
                w = rand(size(x,1),1)*0.01;
                
                % Run the solver with the current hyperparameters
                start = tic;
                gde = solver(x, y, w, alpha, num_iters, lambda_, epsilon, 'GD',mem);
                time = toc(start);
                cost_gde = cost(x, y, gde, lambda_);
                
                start = tic;
                sgd = solver(x, y, w, alpha, num_iters, lambda_, epsilon, 'SGD',mem);
                time = [time, toc(start)];
                cost_sgd = cost(x, y, sgd, lambda_);
                
                start = tic;
                svrg = solver(x, y, w, alpha, num_iters, lambda_, epsilon, 'SVRG',mem);
                time = [time, toc(start)];
                cost_svrg = cost(x, y, svrg, lambda_);
                
                start = tic;
                sag = solver(x, y, w, alpha, num_iters, lambda_, epsilon, 'SAG',mem);
                time = [time, toc(start)];
                cost_sag = cost(x, y, sag, lambda_);
                
                % Increment the counter and store the results
                count = count + 1;
                results(count,:) = [alpha, lambda_, num_iters, epsilon, ...
                    cost_gde, cost_sgd, cost_svrg, cost_sag, ...
                    time(1), time(2), time(3), time(4)];
            end
        end
    end
end

% save('results.mat',"results")
%load('results.mat','results');
% Sort the results by the GD cost
[sorted_cost, sort_idx] = sort(results(:,5));
results_sorted = results(sort_idx,:);

% Print the top 10 results that gives optimal parameters
fprintf('Top 10 results:\n');
fprintf('alpha lambda_ num_iters epsilon cost_gde cost_sgd cost_svrg cost_sag time_gde time_sgd time_svrg time_sag\n');
for i = 1:10
    fprintf('%f %f %d %f %f %f %f %f %f %f %f %f\n', ...
        results_sorted(i,1), results_sorted(i,2), results_sorted(i,3), results_sorted(i,4), ...
        results_sorted(i,5), results_sorted(i,6), results_sorted(i,7), results_sorted(i,8), ...
        results_sorted(i,9), results_sorted(i,10), results_sorted(i,11), results_sorted(i,12))
end

