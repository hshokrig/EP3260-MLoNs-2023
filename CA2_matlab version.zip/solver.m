function W = solver(X,Y, W, alpha, num_iters, lambda_, epsilon, optimizer, mem)
if strcmp(optimizer,'GD')
    for i=1:num_iters
        grad = function_gradient(X,Y,W,lambda_);
        W = W - alpha*grad;
        if mod(i,10)==0 && mem
            r=memory();
            fprintf('mem for GD (MB): %f\n', r.MemUsedMATLAB/1e6);
        end
        if (norm(grad)<=epsilon)
            break;
        end
    end
elseif strcmp(optimizer,'SGD')
    for i=1:num_iters
        indx = randperm(size(Y,2));
        for j=1:size(Y,2)
            grad = function_gradient(X(:,indx(j)),Y(indx(j)),W,lambda_);
            W = W - alpha*grad;
            if mod(i,10)==0 && mem
                r=memory();
                fprintf('mem for GD (MB): %f\n', r.MemUsedMATLAB/1e6);
            end
            if (norm(grad)<=epsilon)
                break;
            end
        end
    end
elseif strcmp(optimizer,'SVRG')
    T = 100;
    K = floor(num_iters/T);
    Z = X*Y';
    N = size(X,2);
    M = zeros([size(X,1),N]);
    for i=1:N  %comple
        M(:,i) = function_gradient(X(:,i),Y(i),W,lambda_);
    end
    for k=1:K
        wz = W'*Z;
        diag = (exp(-1*wz)./(1+exp(-1*wz)).^2)/N;
        G_avg = Z*diag';
        g_avg = mean(G_avg,2);
        w_tilde = W;
        for t=1:T
            idx = randi(N,1);
            g_tilde = function_gradient(X(:,idx),Y(idx),w_tilde,lambda_);
            g_i = function_gradient(X(:,idx),Y(idx),W,lambda_);
            w_tilde = w_tilde - alpha*(g_tilde - g_i + g_avg);
        end
        W = w_tilde;

    end

elseif strcmp(optimizer,'SAG')
    g_hist=zeros(size(X,1),size(X,2));
    mu_hist=zeros(size(X,2),1);
    for i=1:num_iters
        indx=randi(length(Y),1);
        g_hist(:,indx)=function_gradient(X(:,indx),Y(indx),W,lambda_);
        mu_hist(indx)=mean(g_hist(:,indx));
        g_i=g_hist(:,indx)-mu_hist(indx)+mean(g_hist,2);
        W=W-alpha*g_i;
        if norm(g_i)<=epsilon
            break;
        end
    end



end
end
