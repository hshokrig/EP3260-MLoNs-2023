clc
clear 
close all



%% Data Import

list = dir('ghg_data/*.dat');
X=[];
Y=[];
for k=1:length(list)
   dat_file=list(k).name;
   A=importdata(['ghg_data/',dat_file]);
   X=[X; reshape(A(1:15,:),1,[])];
   Y=[Y; reshape(A(16,:),1,[])];
end

X=X';   %4905x2921
Y=Y';   %327x2921


%% Define solvers: GD, SGD, SVRG and SAG. l
alpha = 1; % change the value
num_iters = 1:5:30; % change the value
lambda_ = 0.1; % change the value
epsilon = 0.001; % change the value
mem=false;
cost_plot=[];
for opt_cnt=1:2
    if opt_cnt==1
        opt='GD';
    else
        opt='SGD';
    end


    indx_cnt=1;
    for i=num_iters
        W=rand(size(X,1),size(Y,1));

        W_gd=solver(X,Y,W,alpha,i,lambda_,epsilon,opt,mem);
        cost_plot(indx_cnt,opt_cnt)=cost(X,Y,W_gd,lambda_)
        indx_cnt=indx_cnt+1;
    end
end

plot(num_iters, cost_plot(:,1),num_iters, cost_plot(:,2),LineWidth=1.3)

%W_gd=solver(X,Y,W,alpha,10,lambda_,epsilon,'SVRG',mem);
