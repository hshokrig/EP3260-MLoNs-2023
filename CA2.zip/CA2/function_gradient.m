
function grad = function_gradient(X, Y, w, lambda)
% the gradient of the cost function for logistic ridge regression.

% X -- input features, shape (d1, n)
% Y -- labels, shape (d2, n)
% w -- weights, shape (d1, d2)
% lambda -- regularization parameter

% grad -- logistic ridge regression gradient, shape (d1, d2)

[d, n] = size(X);
grad = zeros(d, 1);
for i = 1:n
    z = -Y(:, i)' * w' * X(:, i);
    sigmoid = 1 / (1 + exp(z));
    grad = grad + (sigmoid - 1) * Y(:, i)' .* X(:, i);
end
grad = grad / n + 2 * lambda * w;

end