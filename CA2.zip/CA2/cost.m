function J = cost(X, Y, w, lambda)
%  cost function for logistic ridge regression.
% X -- input features, shape (d1, n)
% Y -- labels, shape (d2, n)
% w -- weights, shape (d1, d2)
% lambda -- regularization parameter

% J -- logistic ridge regression cost

[d, n] = size(X);
value = 0;
for i = 1:n
    z = -Y(:, i)' * w' * X(:, i);
    value = value + log(1 + exp(z));
end
norm_w = norm(w);
c = lambda * norm_w^2;
J = value / n + c;

end
