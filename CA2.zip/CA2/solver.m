function W = solver(X,Y, W, alpha, num_iters, lambda_, epsilon, optimizer, mem)
if strcmp(optimizer,'GD')
    for i=1:num_iters
        grad = function_gradient(X,Y,W,lambda_);
        W = W - alpha*grad;
        if mod(i,10)==0 && mem
            r=memory();
            fprintf('mem for GD (MB): %f\n', r.MemUsedMATLAB/1e6);
        end
        if (norm(grad)<=epsilon)
            break;
        end
    end
elseif strcmp(optimizer,'SGD')
    for i=1:num_iters
        indx = randperm(size(Y,2));
        for j=1:size(Y,2)
            grad = function_gradient(X(:,indx(j)),Y(:,indx(j)),W,lambda_);
            W = W - alpha*grad;
            if (norm(grad)<=epsilon)
                break;
            end
        end
    end
elseif strcmp(optimizer,'SVRG')
    T = 100;
    K = floor(num_iters/T);
    Z = X*Y';
    N = size(X,2);
    M = zeros([size(X),N]);
    for i=1:N  %comple
        M(:,:,i) = function_gradient(X(:,i),Y(:,i),W,lambda_);
    end
    for k=1:K
        wz = W'*Z;
        diag = (exp(-1*wz)./(1+exp(-1*wz)).^2)/N;
        G_avg = Z*diag';
        g_avg = mean(G_avg,2);
        w_tilde = W;
        for t=1:T
            idx = randi(N);
            g_tilde = function_gradient(X(:,idx),Y(:,idx),w_tilde,lambda_);
            g_i = function_gradient(X(:,idx),Y(idx),W,lambda_);
            w_tilde = w_tilde - alpha*(g_tilde - g_i + g_avg);
        end
        W = w_tilde;
    end
end
end
